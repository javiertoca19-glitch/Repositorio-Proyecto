/* ---------- DATA: platos, bebidas, postres ---------- */
    

    /* ---------- STATE ---------- */
    let CART = {}; // {productId: qty}
    const SHIPPING = 8000; // fixed shipping shown as $8.000

    /* ---------- HELPERS ---------- */
    function formatCOP(n) {
      return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(n);
    }

    function renderCards(list) {
      const container = document.getElementById('cards');
      container.innerHTML = '';
      list.forEach(p => {
        const colorBg = p.type === 'platillo' ? 'from-yellow-400 to-orange-500' : (p.type === 'bebida' ? 'from-green-400 to-blue-500' : 'from-pink-400 to-purple-500');
        const card = document.createElement('article');
        card.className = 'bg-black/40 rounded-2xl p-4 border border-gray-700/30 food-glow hover:scale-105 transition';
        card.innerHTML = `
          <div class="flag-container mb-3">
            <img src="${p.img}" alt="${p.country}" class="flag">
          </div>
          <div class="flex items-start justify-between gap-4">
            <div>
              <h4 class="text-xl font-bold">${p.title} <span class="text-sm ml-2">${p.country}</span></h4>
              <p class="text-sm text-gray-300 mt-1">${p.desc.slice(0, 80)}${p.desc.length>80?'...':''}</p>
            </div>
            <div class="text-right">
              <div class="text-yellow-300 font-bold text-xl">${formatCOP(p.price)}</div>
              <div class="mt-2 flex flex-col gap-2">
                <button data-id="${p.id}" class="open-detail px-3 py-1 rounded-full bg-gray-800/60 text-sm border border-gray-700">Ver</button>
                <button data-id="${p.id}" class="add-cart px-3 py-1 rounded-full text-sm bg-gradient-to-r ${colorBg} text-gray-900 font-bold">Pedir</button>
              </div>
            </div>
          </div>
        `;
        container.appendChild(card);
      });
    }

    function filterAndSort() {
      const type = document.getElementById('filter-type').value;
      const sort = document.getElementById('sort-by').value;
      const searchQ = document.getElementById('search-input')?.value?.toLowerCase() || '';

      let out = PRODUCTS.filter(p => (type === 'all' ? true : p.type === type));
      if (searchQ) {
        out = out.filter(p => (p.title + ' ' + p.country + ' ' + p.desc).toLowerCase().includes(searchQ));
      }

      if (sort === 'price-asc') out.sort((a,b)=>a.price-b.price);
      else if (sort === 'price-desc') out.sort((a,b)=>b.price-a.price);
      else out.sort((a,b)=> (b.popular||0) - (a.popular||0));

      renderCards(out);
    }

    /* ---------- CART UI ---------- */
    function saveCart() {
      localStorage.setItem('gu_cart', JSON.stringify(CART));
      updateCartUI();
    }

    function loadCart() {
      const raw = localStorage.getItem('gu_cart');
      if (raw) CART = JSON.parse(raw);
      else CART = {};
      updateCartUI();
    }

    function addToCart(productId, qty = 1) {
      CART[productId] = (CART[productId] || 0) + qty;
      saveCart();
      showToast('Agregado al carrito');
    }

    function removeFromCart(productId) {
      delete CART[productId];
      saveCart();
    }

    function updateCartUI() {
      // count
      const count = Object.values(CART).reduce((s,n)=>s+n,0);
      document.getElementById('cart-count').textContent = count;

      // items list
      const container = document.getElementById('cart-items');
      container.innerHTML = '';
      if (count === 0) {
        container.innerHTML = '<p class="text-sm text-gray-400">No hay artículos aún.</p>';
      } else {
        for (const [id, qty] of Object.entries(CART)) {
          const p = PRODUCTS.find(x=>x.id===id);
          if (!p) continue;
          const row = document.createElement('div');
          row.className = 'flex justify-between items-center bg-gray-900/40 p-3 rounded';
          row.innerHTML = `
            <div>
              <div class="font-semibold">${p.title}</div>
              <div class="text-xs text-gray-400">${formatCOP(p.price)} × ${qty}</div>
            </div>
            <div class="flex items-center gap-2">
              <button data-id="${id}" class="dec px-2 py-1 rounded bg-gray-800">-</button>
              <div class="px-2">${qty}</div>
              <button data-id="${id}" class="inc px-2 py-1 rounded bg-gray-800">+</button>
              <button data-id="${id}" class="rm ml-3 px-2 py-1 rounded bg-red-600 text-white">Eliminar</button>
            </div>
          `;
          container.appendChild(row);
        }
      }

      // totals
      const subtotal = Object.entries(CART).reduce((s,[id,qty])=>{
        const p = PRODUCTS.find(x=>x.id===id); return s + (p ? p.price * qty : 0);
      },0);
      document.getElementById('subtotal').textContent = formatCOP(subtotal);
      document.getElementById('grandtotal').textContent = formatCOP(subtotal + (count>0 ? SHIPPING : 0));
    }

    /* ---------- MODAL ---------- */
    function openModal(productId) {
      const p = PRODUCTS.find(x=>x.id===productId);
      if (!p) return;
      document.getElementById('modal-flag').src = p.img;
      document.getElementById('modal-title').textContent = p.title;
      document.getElementById('modal-desc').textContent = p.desc;
      document.getElementById('modal-country').textContent = p.country;
      document.getElementById('modal-price').textContent = formatCOP(p.price);
      document.getElementById('modal-add').dataset.id = p.id;
      document.getElementById('modal').classList.remove('hidden');
      document.getElementById('modal').classList.add('flex');
    }

    function closeModal() {
      document.getElementById('modal').classList.add('hidden');
      document.getElementById('modal').classList.remove('flex');
    }

    /* ---------- TOAST ---------- */
    let toastTimer = null;
    function showToast(msg='Hecho') {
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.classList.remove('hidden');
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(()=> t.classList.add('hidden'), 1800);
    }

    /* ---------- INITIALIZE ---------- */
    document.addEventListener('DOMContentLoaded', ()=> {
      // Render cards initially
      renderCards(PRODUCTS);

      // load cart from storage
      loadCart();

      // filter/sort listeners
      document.getElementById('filter-type').addEventListener('change', filterAndSort);
      document.getElementById('sort-by').addEventListener('change', filterAndSort);

      // dynamic clicks (cards)
      document.getElementById('cards').addEventListener('click', (e)=>{
        // open details
        if (e.target.classList.contains('open-detail')) {
          openModal(e.target.dataset.id);
          return;
        }
        // add to cart
        if (e.target.classList.contains('add-cart')) {
          addToCart(e.target.dataset.id, 1);
          return;
        }
      });

      // modal actions
      document.getElementById('modal-close').addEventListener('click', closeModal);
      document.getElementById('modal').addEventListener('click', (ev)=> {
        if (ev.target.id === 'modal') closeModal();
      });
      document.getElementById('modal-add').addEventListener('click', (ev)=>{
        const id = ev.target.dataset.id;
        addToCart(id, 1);
        closeModal();
      });

      // cart item controls (inc/dec/rm)
      document.getElementById('cart-items').addEventListener('click', (e)=>{
        const id = e.target.dataset.id;
        if (!id) return;
        if (e.target.classList.contains('inc')) {
          addToCart(id, 1);
        } else if (e.target.classList.contains('dec')) {
          CART[id] = (CART[id] || 0) - 1;
          if (CART[id] <= 0) delete CART[id];
          saveCart();
        } else if (e.target.classList.contains('rm')) {
          removeFromCart(id);
        }
      });

      // checkout button
      document.getElementById('checkout-btn').addEventListener('click', ()=>{
        const count = Object.values(CART).reduce((s,n)=>s+n,0);
        if (count === 0) {
          alert('Tu carrito está vacío — agrega al menos un artículo.');
          return;
        }
        // Simple checkout flow: show alert with summary and payment instructions
        const subtotal = Object.entries(CART).reduce((s,[id,qty])=>{
          const p = PRODUCTS.find(x=>x.id===id); return s + (p ? p.price * qty : 0);
        },0);
        const total = subtotal + SHIPPING;
        let itemsList = Object.entries(CART).map(([id,qty])=>{
          const p = PRODUCTS.find(x=>x.id===id);
          return `${p.title} x${qty} — ${formatCOP(p.price * qty)}`;
        }).join('\n');

        const message = `Resumen:\n${itemsList}\n\nSubtotal: ${formatCOP(subtotal)}\nEnvio: ${formatCOP(SHIPPING)}\nTotal: ${formatCOP(total)}\n\nPara pagar puedes usar:\n- Nequi / Daviplata: 3148302876\n- O pago en efectivo en puntos Efecty.\n\nEnvía comprobante a info@gastronomiauniversal.com o +57 300 123 4567.`;
        alert(message);
      });

      // Registration form (very simple, no backend)
      document.getElementById('registration-form').addEventListener('submit', (e)=>{
        e.preventDefault();
        const form = e.target;
        const name = form.name.value.trim();
        const email = form.email.value.trim();
        const pass = form.password.value;
        const pass2 = form.password2.value;
        if (pass !== pass2) return alert('Las contraseñas deben coincidir.');
        alert(`¡Gracias ${name}! Registro simulado correcto — revisa tu correo (${email}).`);
        form.reset();
      });

      // toggle search panel
      document.getElementById('toggle-search').addEventListener('click', ()=>{
        const panel = document.getElementById('search-panel');
        panel.classList.toggle('hidden');
      });

      // live search input
      const searchInput = document.getElementById('search-input');
      if (searchInput) {
        searchInput.addEventListener('input', ()=> filterAndSort());
        document.getElementById('search-clear').addEventListener('click', ()=>{ searchInput.value=''; filterAndSort(); });
      }

      // mobile menu
      document.getElementById('btn-mobile-menu').addEventListener('click', ()=>{
        const m = document.getElementById('mobile-menu');
        m.classList.toggle('hidden');
      });

      // open cart button scroll
      document.getElementById('open-cart').addEventListener('click', ()=> {
        document.getElementById('pagos').scrollIntoView({behavior:'smooth'});
      });

      // bind global clicks for dynamically created 'add-cart' buttons inside modal and other places (already handled)
    });

    /* ---------- Populate initial filtered view ---------- */
    // we want the top popular first
    document.addEventListener('DOMContentLoaded', filterAndSort);

    /* ---------- Simple star field generator ---------- */
    (function createStars(){
      const starsContainer = document.getElementById('stars');
      const count = 100;
      for (let i=0;i<count;i++){
        const s = document.createElement('div');
        s.className = 'star';
        const size = Math.random()*2 + 0.6;
        s.style.width = `${size}px`;
        s.style.height = `${size}px`;
        s.style.top = `${Math.random()*100}%`;
        s.style.left = `${Math.random()*100}%`;
        s.style.opacity = (Math.random()*0.8 + 0.15).toString();
        s.style.animationDelay = `${Math.random()*3}s`;
        starsContainer.appendChild(s);
      }
    })();

    /* ---------- Rotating phrases ---------- */
    (function rotatePhrases(){
      const phrases = [
        'Buen provecho — disfruta cada bocado.',
        'Sabores del mundo, cerca de ti.',
        'Cada plato cuenta una historia.',
        'Cocina auténtica y experiencias memorables.',
        'De nuestras manos a tu mesa.',
        'La cocina es el idioma del amor.',
        'Viaja con tu paladar por todos los continentes.',
        'El arte culinario une culturas.',
        'Sabores tradicionales con toque moderno.',
        'Cada bocado es una experiencia inolvidable.'
      ];
      let idx = 0;
      const el = document.getElementById('phrase-text');
      setInterval(()=>{
        idx = (idx+1) % phrases.length;
        el.classList.add('opacity-0','translate-y-2');
        setTimeout(()=> {
          el.textContent = phrases[idx];
          el.classList.remove('opacity-0','translate-y-2');
        }, 300);
      }, 4500);
    })();
