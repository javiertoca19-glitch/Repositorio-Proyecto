const PRODUCTS = [
      /* Platillos */
      {
        id: 'pasta-carbonara',
        type: 'platillo',
        title: 'Pasta Carbonara',
        country: 'Italia 🇮🇹',
        price: 38500,
        img: 'https://upload.wikimedia.org/wikipedia/en/0/03/Flag_of_Italy.svg',
        desc: 'Pasta al dente con panceta ahumada, huevo y parmesano. Clásico italiano.',
        popular: 95
      },
      {
        id: 'sushi-mix',
        type: 'platillo',
        title: 'Sushi Mix',
        country: 'Japón 🇯🇵',
        price: 52000,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9e/Flag_of_Japan.svg',
        desc: 'Selección premium: nigiri, sashimi y makis con pescado fresco.',
        popular: 120
      },
      {
        id: 'tacos-pastor',
        type: 'platillo',
        title: 'Tacos al Pastor',
        country: 'México 🇲🇽',
        price: 28000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/f/fc/Flag_of_Mexico.svg',
        desc: 'Tacos con carne marinada, piña y cilantro sobre tortilla de maíz.',
        popular: 110
      },
      {
        id: 'paella-valenciana',
        type: 'platillo',
        title: 'Paella Valenciana',
        country: 'España 🇪🇸',
        price: 68000,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9a/Flag_of_Spain.svg',
        desc: 'Arroz bomba con mariscos, pollo y azafrán. Tradición española.',
        popular: 80
      },
      {
        id: 'curry-rojo',
        type: 'platillo',
        title: 'Curry Rojo Tailandés',
        country: 'Tailandia 🇹🇭',
        price: 35000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Flag_of_Thailand.svg',
        desc: 'Cremoso con leche de coco y verduras frescas. Ajusta el picante.',
        popular: 88
      },
      {
        id: 'pizza-margherita',
        type: 'platillo',
        title: 'Pizza Margherita',
        country: 'Italia 🇮🇹',
        price: 42000,
        img: 'https://upload.wikimedia.org/wikipedia/en/0/03/Flag_of_Italy.svg',
        desc: 'Masa fermentada 48h, tomate San Marzano, mozzarella y albahaca.',
        popular: 130
      },
      {
        id: 'ramen-tokyo',
        type: 'platillo',
        title: 'Ramen de Tokio',
        country: 'Japón 🇯🇵',
        price: 45000,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9e/Flag_of_Japan.svg',
        desc: 'Sopa de fideos con caldo de hueso, huevo marinado y cerdo chashu.',
        popular: 95
      },
      {
        id: 'ceviche-lima',
        type: 'platillo',
        title: 'Ceviche de Lima',
        country: 'Perú 🇵🇪',
        price: 48000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/c/cf/Flag_of_Peru.svg',
        desc: 'Pescado fresco marinado en limón, cebolla morada y ají limo.',
        popular: 105
      },
      {
        id: 'biryani-mumbai',
        type: 'platillo',
        title: 'Biryani de Mumbai',
        country: 'India 🇮🇳',
        price: 41000,
        img: 'https://upload.wikimedia.org/wikipedia/en/4/41/Flag_of_India.svg',
        desc: 'Arroz basmati con especias, pollo y hierbas aromáticas.',
        popular: 85
      },
      {
        id: 'gyros-atenas',
        type: 'platillo',
        title: 'Gyros de Atenas',
        country: 'Grecia 🇬🇷',
        price: 36000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/5/5c/Flag_of_Greece.svg',
        desc: 'Pan pita con carne de cordero, tomate, cebolla y tzatziki.',
        popular: 75
      },
      {
        id: 'pho-hanoi',
        type: 'platillo',
        title: 'Pho de Hanoi',
        country: 'Vietnam 🇻🇳',
        price: 39000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/2/21/Flag_of_Vietnam.svg',
        desc: 'Sopa de fideos de arroz con caldo de res y hierbas frescas.',
        popular: 90
      },
      {
        id: 'feijoada-rio',
        type: 'platillo',
        title: 'Feijoada de Río',
        country: 'Brasil 🇧🇷',
        price: 52000,
        img: 'https://upload.wikimedia.org/wikipedia/en/0/05/Flag_of_Brazil.svg',
        desc: 'Frijoles negros con carne de cerdo, chorizo y arroz blanco.',
        popular: 88
      },

      /* Bebidas */
      {
        id: 'mate',
        type: 'bebida',
        title: 'Mate Tradicional',
        country: 'Argentina 🇦🇷',
        price: 7000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/1/1a/Flag_of_Argentina.svg',
        desc: 'Infusión popular en el Cono Sur, sabor amargo y social.',
        popular: 40
      },
      {
        id: 'chai-latte',
        type: 'bebida',
        title: 'Chai Latte',
        country: 'India 🇮🇳',
        price: 9000,
        img: 'https://upload.wikimedia.org/wikipedia/en/4/41/Flag_of_India.svg',
        desc: 'Mezcla de especias, leche y té negro. Aromático y reconfortante.',
        popular: 60
      },
      {
        id: 'limonada-fresa',
        type: 'bebida',
        title: 'Limonada de Fresa',
        country: 'Colombia 🇨🇴',
        price: 7000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/2/21/Flag_of_Colombia.svg',
        desc: 'Refrescante limonada con puré de fresas.',
        popular: 55
      },
      {
        id: 'margarita-cancun',
        type: 'bebida',
        title: 'Margarita de Cancún',
        country: 'México 🇲🇽',
        price: 18000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/f/fc/Flag_of_Mexico.svg',
        desc: 'Cóctel clásico con tequila, triple seco y jugo de limón.',
        popular: 70
      },
      {
        id: 'mojito-habana',
        type: 'bebida',
        title: 'Mojito de La Habana',
        country: 'Cuba 🇨🇺',
        price: 16000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/b/bd/Flag_of_Cuba.svg',
        desc: 'Ron blanco, menta fresca, azúcar, limón y soda.',
        popular: 85
      },
      {
        id: 'caipirinha-rio',
        type: 'bebida',
        title: 'Caipirinha de Río',
        country: 'Brasil 🇧🇷',
        price: 17000,
        img: 'https://upload.wikimedia.org/wikipedia/en/0/05/Flag_of_Brazil.svg',
        desc: 'Cachaça, lima cortada, azúcar y hielo machacado.',
        popular: 65
      },
      {
        id: 'sangria-barcelona',
        type: 'bebida',
        title: 'Sangría de Barcelona',
        country: 'España 🇪🇸',
        price: 22000,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9a/Flag_of_Spain.svg',
        desc: 'Vino tinto con frutas frescas, brandy y un toque de azúcar.',
        popular: 78
      },
      {
        id: 'bubble-tea-taipei',
        type: 'bebida',
        title: 'Bubble Tea de Taipei',
        country: 'Taiwán 🇹🇼',
        price: 12000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/7/72/Flag_of_the_Republic_of_China.svg',
        desc: 'Té con leche, sirope y perlas de tapioca masticables.',
        popular: 95
      },
      {
        id: 'espresso-roma',
        type: 'bebida',
        title: 'Espresso de Roma',
        country: 'Italia 🇮🇹',
        price: 8000,
        img: 'https://upload.wikimedia.org/wikipedia/en/0/03/Flag_of_Italy.svg',
        desc: 'Café concentrado con crema dorada, servido en taza pequeña.',
        popular: 88
      },
      {
        id: 'horchata-valencia',
        type: 'bebida',
        title: 'Horchata de Valencia',
        country: 'España 🇪🇸',
        price: 9500,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9a/Flag_of_Spain.svg',
        desc: 'Bebida refrescante hecha de chufa, agua y azúcar.',
        popular: 60
      },

      /* Postres */
      {
        id: 'tiramisu',
        type: 'postre',
        title: 'Tiramisú',
        country: 'Italia 🇮🇹',
        price: 14000,
        img: 'https://upload.wikimedia.org/wikipedia/en/0/03/Flag_of_Italy.svg',
        desc: 'Clásico postre con capas de mascarpone, café y cacao.',
        popular: 75
      },
      {
        id: 'flan-cremoso',
        type: 'postre',
        title: 'Flan Cremoso',
        country: 'España 🇪🇸',
        price: 9000,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9a/Flag_of_Spain.svg',
        desc: 'Textura suave y caramelo dorado.',
        popular: 45
      },
      {
        id: 'brownie-choco',
        type: 'postre',
        title: 'Brownie de Chocolate',
        country: 'EE. UU. 🇺🇸',
        price: 11000,
        img: 'https://upload.wikimedia.org/wikipedia/en/a/a4/Flag_of_the_United_States.svg',
        desc: 'Denso, húmedo y con trozos de chocolate.',
        popular: 95
      },
      {
        id: 'creme-brulee-paris',
        type: 'postre',
        title: 'Crème Brûlée de París',
        country: 'Francia 🇫🇷',
        price: 16000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/c/c3/Flag_of_France.svg',
        desc: 'Crema de vainilla con capa crujiente de caramelo quemado.',
        popular: 80
      },
      {
        id: 'baklava-istanbul',
        type: 'postre',
        title: 'Baklava de Estambul',
        country: 'Turquía 🇹🇷',
        price: 13000,
        img: 'https://upload.wikimedia.org/wikipedia/commons/b/b4/Flag_of_Turkey.svg',
        desc: 'Capas de masa filo con nueces y miel, servido en porciones.',
        popular: 70
      },
      {
        id: 'mochi-kyoto',
        type: 'postre',
        title: 'Mochi de Kioto',
        country: 'Japón 🇯🇵',
        price: 12000,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9e/Flag_of_Japan.svg',
        desc: 'Bolas de arroz glutinoso rellenas de pasta de frijol rojo.',
        popular: 85
      },
      {
        id: 'churros-madrid',
        type: 'postre',
        title: 'Churros de Madrid',
        country: 'España 🇪🇸',
        price: 10000,
        img: 'https://upload.wikimedia.org/wikipedia/en/9/9a/Flag_of_Spain.svg',
        desc: 'Dulce frito crujiente con azúcar y canela, ideal con chocolate.',
        popular: 78
      },
      {
        id: 'pavlova-sydney',
        type: 'postre',
        title: 'Pavlova de Sídney',
        country: 'Australia 🇦🇺',
        price: 15000,
        img: 'https://upload.wikimedia.org/wikipedia/en/b/b9/Flag_of_Australia.svg',
        desc: 'Merengue crujiente por fuera y suave por dentro con frutas frescas.',
        popular: 65
      },
      {
        id: 'tarta-limón-londres',
        type: 'postre',
        title: 'Tarta de Limón de Londres',
        country: 'Reino Unido 🇬🇧',
        price: 13500,
        img: 'https://upload.wikimedia.org/wikipedia/en/a/ae/Flag_of_the_United_Kingdom.svg',
        desc: 'Base de galleta con relleno ácido de limón y crema batida.',
        popular: 72
      },
      {
        id: 'knafeh-amman',
        type: 'postre',
        title: 'Knafeh de Ammán',
        country: 'Jordania 🇯🇴',
        price: 14500,
        img: 'https://upload.wikimedia.org/wikipedia/commons/c/c0/Flag_of_Jordan.svg',
        desc: 'Queso dulce entre capas de masa fina con sirope de rosas.',
        popular: 68
      }
    ];
